def lambda_handler(event, context):
    message = "hello world !!!"

    return {
        message : message
    }